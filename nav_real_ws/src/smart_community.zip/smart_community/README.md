# smart_community (ROS Melodic workspace)

This workspace provides a minimal catkin workspace for the Province Contest - Problem 1 (map + models placed).
It is prepared for **ROS Melodic** and **Gazebo9**.

## Structure
```
/mnt/data/smart_ws/
  src/
    smart_community/
      worlds/smart_community.world
      models/               (models extracted from your model-zhsq.zip or auto-generated placeholders)
      launch/start_world.launch
      scripts/spawn_models.sh
      package.xml
      CMakeLists.txt
      docs/screenshots/     (placeholder for screenshots)
```
## How to run (on a machine with ROS Melodic installed)
1. Build workspace (if you have any packages that need building):
```
cd /mnt/data/smart_ws
catkin_make
source devel/setup.bash
```
2. Start Gazebo with the prepared world:
```
roslaunch smart_community start_world.launch
```
3. (Optional) In a second terminal, source ROS and run spawn script to spawn models (if not already included in world):
```
source /opt/ros/melodic/setup.bash
source /mnt/data/smart_ws/devel/setup.bash  # optional
roscd smart_community/scripts
./spawn_models.sh
```
Note: The `spawn_models.sh` uses `rosrun gazebo_ros spawn_model` and expects the model `.sdf` files inside `src/smart_community/models/<modelname>`. The world file already includes the first three models in the `models/` directory by <include> tags; spawn script is provided for convenience.

## Map and scale
- The map image (map.png) is placed into `worlds/`. The world contains a textured plane of size **3.6 x 3.6 m** to match the map's scale.
- Model coordinates were assigned with reasonable example positions. If you want exact pixel-to-meter mapping changes, edit `worlds/smart_community.world` or the spawn script coordinates.

## Notes
- If your uploaded zip contained proper Gazebo model directories (with model.config and .sdf), they were extracted to `src/smart_community/models/` and used.
- If some models lacked .sdf or model.config, placeholder SDFs were auto-generated (simple box models).

## What I did *not* implement (per your request)
- Vehicle dynamics, controllers or recognition modules were not included.
- This workspace is minimal to allow you to run the world and verify model placement.

---
If you'd like, I can now:
- Adjust exact coordinates to match PDF pixel positions (I can compute exact pixel->meter mapping),
- Replace placeholder models with more accurate meshes from your zip if you upload missing files,
- Add a launch that copies models into ~/.gazebo/models automatically.
