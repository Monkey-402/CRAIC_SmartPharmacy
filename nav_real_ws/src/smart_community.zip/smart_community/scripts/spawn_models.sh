#!/bin/bash

# Source ROS (user may need to adjust for their system)
# source /opt/ros/melodic/setup.bash

MODELPATH=$(rospack find smart_community)/models
export GAZEBO_MODEL_PATH=$MODELPATH:$GAZEBO_MODEL_PATH

rosrun gazebo_ros spawn_model -file $MODELPATH/cp/model.sdf -sdf -model cp -x -0.9 -y 0.6 -z 0.0 -Y 1.5708
rosrun gazebo_ros spawn_model -file $MODELPATH/ro1/model.sdf -sdf -model ro1 -x -0.9 -y -0.2 -z 0.0 -Y 1.5708
rosrun gazebo_ros spawn_model -file $MODELPATH/ro2/model.sdf -sdf -model ro2 -x 1.2 -y -0.3 -z 0.0 -Y 1.5708
